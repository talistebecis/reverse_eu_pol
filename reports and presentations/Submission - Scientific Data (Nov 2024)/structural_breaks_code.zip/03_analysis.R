# clean memory
rm(list=ls())
set.seed(1230)

# Group specifications
EU15 <- c("Austria", "Belgium", "Germany", "Denmark", "Spain", "Finland",
          "France", "United Kingdom", "Ireland", "Italy", "Luxembourg", 
          "Netherlands", "Greece", "Portugal", "Sweden")

OECD <- c(EU15, "Czechia","Estonia", "Hungary", "Lithuania", "Latvia",
          "Poland", "Slovak Republic", "Slovenia", "Switzerland", 
          "Iceland", "Norway", "Australia", "Canada","Chile",
          "Colombia", "Costa Rica", "Israel", "Japan",
          "Korea, Rep.", "Mexico", "New Zealand", "Turkiye", "United States")

# Choose gas (options: all_ghg, co2, ch4, n2o, fgas)
gas <- "all_ghg"

# choose sample (options: EU15, OECD)
sample <- EU15

# choose sector (refer to "IPCC 2006 Categories" document for all sectors)
emissions_code <- "1.A.1.a" # add category of interest
emissions_category <- "Main Activity Electricity and Heat Production" # add category of interest

# import emissions data
dat <- read.csv(paste0(gas,".csv")) %>% 
  filter(category == emissions_code,
         country %in% sample,
         year>=1995)

# set file name to emissions category
file_name <- paste0(emissions_category)

# create document header
cat(
  paste0(
    "#################################################################### \n",
    "#                                                                  # \n",
    "#                 CO2 DRIVERS EU - ANALYSIS                        # \n",
    "#                                                                  # \n",
    "#################################################################### \n",
    "\n \n \n"),
  file = file_name
)

cat(
  paste0(
    "############################## \n",
    "#  COUNTRIES = ", length(sample), " \n",
    "############################## \n",
    "\n \n "),
  file = file_name,
  append = T
)

# run analysis
for(p.value in c(.05, .01, .001)){
  
  # Break analysis:
  is <- isatpanel(
    data = dat,
    formula = "lemissions_pc ~ lgdp + lgdp_sq + lpop" %>% as.formula,
    index = c("country", "year"),
    effect = "twoways",
    iis = T,
    fesis = T, 
    t.pval=p.value
  )
  
  # Print analysis results
  cat(
    paste0(
      " \n ###########################", 
      " \n # p-value: ", p.value,
      " \n \n "), 
    file = file_name, 
    append = T)
  
  sink(file_name, append=T)
  print(is)
  sink()
  
  cat(" \n \n \n \n \n", 
      file = file_name, 
      append = T)
}
