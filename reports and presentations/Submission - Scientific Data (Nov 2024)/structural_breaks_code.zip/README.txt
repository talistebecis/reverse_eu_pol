A dataset of structural breaks in greenhouse gas emissions for climate policy evaluation

Instructions to replicate the main results:

1. Copy all files and folders to a location of your choice.
2. Open “01_master_script.R” in R.
3. Install the R packages indicated on lines 4 to 15. Note, "getspanel" has to be installed manually from GitHub (use the code on line 13).
4. Update line 17 of the code to indicate where you copied the data in Step 1 (your working directory).
5. Execute the script.

Note, many parameters in the code can be tweaked to analyse different gases, sectors and samples. By default, the code analyses all GHGs (combined, terms of CO2-equivalents), for EU15 countries in the category "Main Activity Electricity and Heat Production". Instructions to select different parameters are given in the code itself.