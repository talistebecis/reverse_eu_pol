# clean memory
rm(list=ls())

# load libraries
library(dplyr)
library(tidyr)
library(readxl)
library(stringr)
library(gets)
library(devtools)

# install the "getspanel" package directly from GitHub
# devtools::install_github("moritzpschwarz/getspanel")
library(getspanel)

# set working directory
dir <- "A:/"
setwd(dir)

# call scripts
# create datasets
source("01_create_dataset.R")

# analysis
source("02_analysis.R")